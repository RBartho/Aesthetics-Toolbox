%Computing the balance point according to Bauerly & Liu (2010) and McManus et al. (2011)
%Balance is then the Euclidean distance to the geometric center
%Whether picture has to be inverted is decided by gray level histogram 
function [rdist, htmp, vtmp, area, inv] = f_DCM_Key(im)

    im = rgb2gray(im);  %convert image to binary im_comp image
    s = size(im);
    height = s(1);
    width = s(2);
    [counts, binLocations] = imhist(im); 
    thres = 128;
%Summing up the gray values
	sum1 = 0;
	for i = 1:thres
		sum1 = sum1 + counts(i);
    end
	sum2 = 0;
	for i = thres:256
		sum2 = sum2 + counts(i);
    end
	if (sum1 <= sum2) %if there are more light pixels than dark ones, invert picture
        im_comp = imcomplement(im); %reverse black and white
		inv = 'inverted';
    else
        im_comp = im; 
       	inv = 'original';
    end
    
    nall = sum(im_comp(:));  %nr of black pixel
    
    % horizontal balance point
    r = 0; 
    for i = 1:width
        w = sum(im_comp(:,i));
        r = r + w*i;
    end
    Rh = round(r/nall);  %x position of fulcrum
    Rhnorm = Rh/width; %normalized

    % vertical balance point
    r = 0; 
    for i = 1:height
        w = sum(im_comp(i,:));
        r = r + w*i;
    end
    Rv = round(r/nall);  %y position of fulcrum
    Rvnorm = Rv/height; %normalized
 
    htmp = 0.5-Rhnorm;
    vtmp = 0.5-Rvnorm;

    dist = sqrt(htmp^2 + vtmp^2);
    rdist = (dist/0.5)*100;
      %calculate direction in degree
    xcenter = width/2;
    ycenter = height/2;
    %direction goes from 0 to 180� (upper half, right to left ), from 0 to
    %-180� lower half (right to left)
    direction = atan2d(ycenter-Rv,Rh-xcenter);
    if (direction >= 45)&&(direction < 135)
        area = 1; %top
    elseif (direction >= 135)||(direction < -135)
        area = 2;%left
    elseif (direction >= -135)&&(direction < -45)
        area = 3; % bottom
    else
        area = 4; %right
    end

