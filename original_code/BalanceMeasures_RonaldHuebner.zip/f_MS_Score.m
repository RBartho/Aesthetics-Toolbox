%Computing the balance score according to Wilson & Chatterjee (2010)
function [ms] = f_MS_Score(im)
%    imshow(im);
    level = graythresh(im); %automatically find optimal level
    BW = im2bw(im,level);  %convert image to binary bw image
    BW = imcomplement(BW); %reverse black and white
    s = size(BW);
    height = s(1);
    width = s(2);
    nall = sum(BW(:));  %nr of black pixel
    
    % horizontal axis of reflexion (vertical reflection).
%    w = width;
    if mod(height,2) == 0  % even number
        h2 = height/2;
    else
        h2 = (height-1)/2;
    end
    n1 = h2-1;
    sym = 0;
    for i = 1:width 
        for j = 1:h2
            sym = sym + (BW(j,i)*BW(height-(j-1),i))*(1+(j-1)/(n1));
        end
    end
    Sh = sym*(2/(3*width*h2));

    % vertical axis of reflexion (horizontal reflection)
%    h = height;
    if mod(width,2) == 0  % even number
        w2 = width/2;
    else
        w2 = (width-1)/2;
    end
    n1 = w2-1;
    sym = 0;
    for i = 1:height 
        for j = 1:w2
            sym = sym + (BW(i,j)*BW(i,width-(j-1)))*(1+(j-1)/(n1));
        end
    end
    Sv = sym*(2/(3*height*w2));
    
    if width == height 
        % major diagonal of reflexion, ONLY FOR SQUARES!!!!!!!!!
        sym = 0;
        n = 1; %pixel until diagonal
        for i = 2:height
            for j = 1:n
                sym = sym + (BW(i,j)*BW(j,i))*(1+j/n);
            end
            n = n +1;
        end
        Smd = sym*(2/(3*height*(width-1)/2));


        % minor diagonal of reflexion, ONLY FOR SQUARES!!!!!!!!!
        BW = imrotate(BW, 90);
        sym = 0;
        n = 1; %pixel until diagonal
        for i = 2:height 
            for j = 1:n
                sym = sym + (BW(i,j)*BW(j,i))*(1+j/n);
            end
            n = n +1;
        end
        Sad = sym*(2/(3*height*(width-1)/2));

        ms = ((Sh+Sv+Smd+Sad)/4)*100;
    else
        ms = ((Sh+Sv)/2)*100;
    end
    %fprintf(fileID,'%6.4f %6.4f %6.4f %6.4f %6.2f',Sh, Sv, Smd, Sad, meansym);
