% computes the relative entropy in percent
function [en_all, en_hori, en_vert, en_av] = f_Entropy_Score_2d(im, hbins, vbins)
% Arguments:  
% im - image: RGB or graylevel
% hbins - number of bins in the horizontal dimension 
% vbins - number of bins in the vertical dimension

% Output: (Entropies in percent) 
% en_all - Entropy across all cells (hbins x vbins)
% en_hori - Entropy across horizontal bins (hbins)
% en_vert - Entropy across vertical bins (vbins)
% en_av - mean of en_hori and en_vert


    if nargin < 3   
        error('Not enough arguments!');      
    end
   
    im = rgb2gray(im);  %convert image to gray level image
    s = size(im);
    height = s(1);
    width = s(2);
    [counts, binLocations] = imhist(im); 
    thres = 128;
    %Summing up the gray values
	sum1 = 0;
	for i = 1:thres
		sum1 = sum1 + counts(i);
    end
	sum2 = 0;
	for i = thres:256
		sum2 = sum2 + counts(i);
    end
	if (sum1 <= sum2) %if there are more light pixels than dark ones, invert picture
        im_comp = imcomplement(im); %reverse black and white
		inv = 'inverted';
    else
        im_comp = im; 
       	inv = 'original';
    end

    BW = im2bw(im_comp,level);  %convert image to binary bw image
%    imshow(BW);

    % summing values within cells, defined by the bins
    hinc = floor(width/hbins); %horizontal increment; some pixel may be missed due to rounding
    vinc = floor(height/vbins);
    hresiduals = width - hbins*hinc; %residuals 
    vresiduals = height - vbins*vinc;
    
    x = zeros(vbins,hbins); % Attention! vbins become rows
    for i = 1:hbins % columns
        hstart = (i-1)*hinc + 1;
        if (i == hbins)
            hend = i*hinc + hresiduals; %last bin takes the residuals
        else
            hend = i*hinc;
        end
        for j = 1:vbins % rows
            vstart = (j-1)*vinc + 1;
            if (j == vbins)
                vend = j*vinc + vresiduals; % last bin takes the residuals
            else
                vend = j*vinc;
            end
            x(j,i) = sum(sum(BW(vstart:vend, hstart:hend))); 
        end
    end
    nbins = hbins*vbins; %number of cells
    max = log2(nbins);  % max entropy
    xh = reshape(x, [nbins,1]); % vector from matrix 
    all = sum(xh); % sum up all values
    % Make mask to eliminate 0's since log2(0) = -inf.
    j = find(x);  % returns indizes of non-zero elements         
% all cells
    xh = xh ./ all; % compute probability 
    hx = -sum(xh(j) .* log2(xh(j)));       % Compute entropy
    en_all = (hx/max)*100; 

    max = log2(hbins);  % max entropy
% horizontal, summing across rows 
    y = sum(x)./ all;
    j = find(y);           
    en = -sum(y(j) .* log2(y(j)));       % Compute entropy
    en_hori = (en/max)*100; 

    max = log2(vbins);  % max entropy
% vertical, summing across columns 
    y = sum(transpose(x))./ all;
    j = find(y);           
    en = -sum(y(j) .* log2(y(j)));       % Compute entropy
    en_vert = (en/max)*100; 

% average of horizontal and vertical
    en_av = (en_hori + en_vert)/2;
