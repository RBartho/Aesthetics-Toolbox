%Computing the balance score according to Wilson & Chatterjee (2010)
function [bs] = f_APB_Score(im)

    im = rgb2gray(im);  %convert image to binary im_comp image
    s = size(im);
    height = s(1);
    width = s(2);
    [counts, binLocations] = imhist(im); 
    thres = 128;
%Summing up the gray values
	sum1 = 0;
	for i = 1:thres
		sum1 = sum1 + counts(i);
    end
	sum2 = 0;
	for i = thres:256
		sum2 = sum2 + counts(i);
    end
	if (sum1 <= sum2) %if there are more light pixels than dark ones, invert picture
        im_comp = imcomplement(im); %reverse black and white
		inv = 'inverted';
    else
        im_comp = im; 
       	inv = 'original';
    end
    
    nall = sum(im_comp(:));  %nr of black pixel

    %  horizontal balance
    w = round(width/2); % disregarding center column if width uneven 

    s1 = sum(sum(im_comp(:,1:w)));   
    s2 = sum(sum(im_comp(:,width-w+1:width)));
    bh = (abs(s1-s2)/nall)*100; %horizontal

    w2 = floor(width/4); % adding center row of w to middle area if w uneven 

    s1 = sum(sum(im_comp(:,1:w2)));
    s2 = sum(sum(im_comp(:,width-w2+1:width)));

    bioh = (abs((nall-(s1+s2))-(s1+s2))/nall)*100; %  inner-outer horizontal 


    %  vertical balance

    h = floor(height/2); 

    s1 = sum(sum(im_comp(1:h,:)));   
    s2 = sum(sum(im_comp(height-h+1:height,:)));
    bv = (abs(s1-s2)/nall)*100; %vertical

    h2 = floor(height/4); 
    s1 = sum(sum(im_comp(1:h2,:)));
    s2 = sum(sum(im_comp(height-h2+1:height,:)));

    biov = (abs((nall-(s1+s2))-(s1+s2))/nall)*100; %  inner-outer vertical


    %  main diagonal and inner outer (bottom right top left)
    
    s1 = sum(sum(triu(im_comp,1)));  % above the main diagonal 
    s2 = sum(sum(tril(im_comp,-1))); % below the main diagonal 
    bmd = (abs(s1-s2)/nall)*100;  % main diagonal
    
    prop = 1/sqrt(2); % to get same area for inner and outer
    b1 = height - floor(height*prop);
    b2 = width - floor(width*prop);
    s1 = sum(sum(tril(im_comp,-b1))); % lower left part 
    s2 = sum(sum(triu(im_comp,b2))); % upper right part 
    biomd = (abs((nall - (s1+s2)) - (s1+s2))/nall)*100; %inner-outer 

    %  antidiagonal and inner outer (bottom right top left)
    im_comp = imrotate(im_comp, 90);
    %rotation requires exchange of width and height
    s1 = sum(sum(triu(im_comp,1))); % above main diagonal 
    s2 = sum(sum(tril(im_comp,-1))); % below main diagonal 
    bad = (abs(s1-s2)/nall)*100;  % main diagonal
 
    s1 = sum(sum(tril(im_comp,-b2))); % lower left part 
    s2 = sum(sum(triu(im_comp,b1))); % upper right part 
    bioad = (abs((nall - (s1+s2)) - (s1+s2))/nall)*100; %inner-outer 


    bs = (bh+bv+bioh+biov+bmd+biomd+bad+bioad)/8;
