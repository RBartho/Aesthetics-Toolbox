How to calculate edge orientation entropy

Redies, C., Brachmann, A., Wagemans, J. (2017) High entropy of edge orientations characterizes visual artworks from diverse cultural backgrounds. Vision Research 133:130-144

A bug was found in line 159 of the original version of this program:

counts, tuple([distance_rel, direction, orientations_rel]), filter_img.resp_val[ey,ex] * filter_img.resp_val[ey[cp],ex[cp]]
The effect of this bug has been that, for some pixel pairs, not all theta angles were entered into the theta histograms. As a result, the absolute calculated entropy values were lower. However, relative differences in the entropies are stable.

This bug has been corrected as follows:

np.add.at(counts, tuple([distance_rel, direction, orientations_rel]), filter_img.resp_val[ey,ex] * filter_img.resp_val[ey[cp],ex[cp]])

This modification ensures that all available values are entered into the theta histogram for each distance d and angle alpha.

The absolute entropy values may be slightly lower for the corrected version of the program, compared to the original program. Importantly, relative differences of entropy between images are close to unchanged. The Pearson correlation coefficient r between the values calculated with the original version and the values calculated with the debugged version is 0.99 for a diverse set of 4,500 photographs of natural and man-made scenes and objects, including photographs of artworks.

For purposes of comparison between images, the same version of the program should be used, preferably the debugged one.I apologise for any inconvenience which this error may have caused.

If you have any questions, please do not hesitate to contact:
Christoph RediesExperimental Aesthetic GroupInstitute of AnatomyUniversity of Jena School of MedicineE-Mail: christoph.redies@med.uni-jena.de