% Custom Differential Box Count algorithm, based on combining:
%
% Jin et al.(1995), Li et al. (2009), Liu et al. (2014)

% Min and max box sizes as defined by Jin.
% Box overlap as defined by Li.
% Box number calculation as defined by Li.
% Block count as defined by Jin.
%
% Inputs:
%       I         image matrix
%       suppress  flag to suppress graphical output (1=suppress)
% Outputs:
%       D         Measured fractal dimension (box count)
%       pcorr     Correlation coefficient of linear fit
%       psig      Significance of correlation coeff
%
% This version - GM, April, 2017.
%
% Available under CC-BY-NC license
% Please cite: 
% Mather, G. (2017) Visual statistics of large samples of Western artworks. Art & Perception, 5, 368.
% Mather, G. (submitted) Visual statistics in the history of Western art. Art & Perception, under review.
%

function  [D, pcorr, psig] = CDBC(I, suppress)

if ~exist('suppress', 'var')
    suppress = 1; % default value 
end
[nr, nc, G] = size(I);

% calc min & max box sizes
% Use powers of two, so reqs power-of-two image w & h
% Liu et al. 2014, section 3.3 p.1105

% Define range: min and max box sizes
% As defined by Jin et al. 1995. Eq(7) & (11)
%------
minpow = nextpow2(nr^(1/3));
bmin = 2^minpow;
bmax = bmin;
while (ceil(nr/bmax)+1) <= ceil(nr/(bmax-1))
    bmax = bmax+1;
end
boxes = (bmin:2:bmax);

boxHeights = boxes*(double(G)/double(nr));  % box size in greylevels

boxCounts = zeros(1, length(boxes));
boxSizes = zeros(1, length(boxes));

% loop through the box sizes
ib=1;
for b = 1:length(boxes)
    bs = boxes(b);
    bh = boxHeights(b);% box size in greylevels
    
    % Divide the image into a grid of boxes (bs x bs). 
    % Loop through the cells in the grid, calclulating the boxcount for 
    % each and adding it to the running total.
    % Overlap columns by one x-pixel as in Li et al. 2009 sec.3.4
    boxCount = 0;
    for by = 1: bs: nc-bs
        for bx = 1: bs-1: nr-bs
            % get the 'column' of pixels in the box
            submat = I(by:by+bs-1,bx:bx+bs-1);
            l = max(submat(:));
            k = min(submat(:));
            
            % Box number calculation (Li et al. 2009, Eq.(6)
            if l == k
                b1 = 1;
            else
                % calculate box count as in Jin et al. 1995 Eq.(6)
                b1 = ceil(double(l-k)/double(bh));
            end
           boxCount = boxCount + b1;
           
        end
    end
    % Now use the range of box sizes to calc D
    boxCounts(ib) = (boxCount);
    boxSizes(ib) = (1.0/double(bs));
%    fprintf('Size: %g Count: %g\n',boxSizes(ib), boxCounts(ib));
    ib = ib+1;
end

dfit = polyfit(log(boxSizes), log(boxCounts), 1);
D = dfit(1);

xInt = linspace(min(boxSizes(:)),max(boxSizes(:)),length(boxSizes));

yInt = exp(dfit(2))*xInt.^(dfit(1));

% Correlation
[r ,p] = corrcoef(log(boxSizes), log(boxCounts));
pcorr = r(1,2);
psig = p(1,2);
if psig < 0.00001
    psig = 0.00001;
end

% Plot graph if required
if suppress == 0
    figure
    loglog(boxSizes,boxCounts,'g*',xInt,yInt,'b'); % linear regression in (logx,logy) 
    title (['CDBC: FD = ' num2str(D)])
end


    
    



