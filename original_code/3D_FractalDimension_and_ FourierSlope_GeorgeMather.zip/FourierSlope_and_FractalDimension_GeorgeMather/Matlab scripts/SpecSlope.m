function [slope, pcorr, psig] = SpecSlope (cg, suppress)
% Calculate spectral slope of image
%
% Inputs:
%       cg        Image matrix
%       suppress  Flag to suppress graph output (0 or 1)
% Outputs:
%       slope     Measured spectral slope
%       pcorr     Correlation coefficient of linear fit
%       psig      Significance of correlation coeff
%
% Takes rotational average of spectrum before linear fit to component amps
% Linear fit excludes SFs below (1/25 x max SF) and above (0.5 x max SF)
% This restriction also used by others e.g. Redies
%
% This version - GM April 2017
%
% Available under CC-BY-NC license
% Please cite: 
% Mather, G. (2017) Visual statistics of large samples of Western artworks. Art & Perception, 5, 368.
% Mather, G. (submitted) Visual statistics in the history of Western art. Art & Perception, under review.
%
[nr, nc, N] = size(cg); 
% ----- Spectral slope -----
minf = round((nr/2)*(1/25));% Max SF is (nr/2); discard lowest few freqs
maxf = round((nr/2)* 0.5); % & highest half of spectrum

% fft of image
cgs = double(cg)/255;
imsp = fft2(cgs(:,:,1));
Y  = fftshift(imsp);

impf = abs(Y).^2;

if suppress == 0
    figure
    imshow(log(impf),[]);
end

Pf = rotavg(impf);
f1 = 0:nr/2;

f11 = f1(1, minf:maxf);
Pf1 = Pf(minf:maxf,1)';
c = polyfit(log(f11),log(Pf1),1);
slope = (c(1))/2;

%fprintf('Spectral slope (pow/amp) = %g/%g\n', slope, slope/2);
xInt = linspace(f1(minf),f1(maxf),100);

yInt = exp(c(2))*xInt.^(c(1));
if suppress == 0
    figure
    loglog(f11,Pf1,'g*',xInt,yInt,'b'); % linear regression in (logx,logy) 
end
[r ,p] = corrcoef(log(f11), log(Pf1));
pcorr = r(1,2);
psig = p(1,2);
if psig < 0.00001
    psig = 0.00001;
end
% print data for plotting slope graph
% for d = 1: length(xInt)
%     fprintf('%g\t%g\t%g\t%g\n',f11(d),Pf1(d),xInt(d),yInt(d));
% end
