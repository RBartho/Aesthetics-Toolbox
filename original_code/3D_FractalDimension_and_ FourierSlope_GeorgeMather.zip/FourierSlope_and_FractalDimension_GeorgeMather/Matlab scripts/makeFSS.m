function makeFSS(wid, D, num)
% Make a random fractal by Fourier Spectral Synthesis.
% Based on:
%       Saupe, D. (1988) Algorithms for random fractals. In: Peitgen, H.,
%       Saupe, D. "The Science of Fractal Images". pp. 71-136. 
%       Springer-Verlag, New York.
% Matlab implementation of SpectralSynthesisFM2D (p.108)
%
% Inputs:
%       wid   Width/height of required image
%       D     Fractal Dimension of required image (2 < D < 3)
%       num   Number of randomly different images to generate
%
% Power Spectral slope (SP) is calculated from D as:
%       SP = 8-(2*D); also D = (8-SP)/2
% See:
%       Knill, D. C., Field, D., & Kersten, D. (1990). Human discrimination 
%       of fractal images. JOSA A, 7(6), 1113-1123.
%       (Eq. 18, p.1121)
%
% So amplitude spectral slope (SA) is calculated from D as follows:
%       SA = (8-(2*D))/2;
%       (because SA = SP/2)
%
% Writes each image to a PNG file, with name:
%       'Cloudv2_<file no.>_<wid>_<D * 10>_<SA * 10>.png'
%
% Available under CC-BY-NC license
% Please cite: 
% Mather, G. (2017) Visual statistics of large samples of Western artworks. Art & Perception, 5, 368.
% Mather, G. (submitted) Visual statistics in the history of Western art. Art & Perception, under review.

    N = wid;% Width/Height of image
    H = 3-D;
    showim = 0; % Flag display created image (0 or 1)

    nomAmpSlope = (8-(2*D))/2; % Knill et al.'s formula, derived from Voss 

    for fn = 1:num
        fname = ['Cloudv2_', num2str(fn), '_',num2str(N),'_',num2str(D*10),'_',num2str(nomAmpSlope*10),'.png'];

        % --- Saupe algorithm ---
        % Generates random spectral components at the appropriate spectral
        % density for specified value of H (which determines D) 
        A1 = zeros(N,N);
        A = complex(A1,0);

        for i=0:N/2
            for j=0:N/2
                phase = 2*pi*rand();
                if (i >0 || j>0)
                rad = power(i*i+j*j,-(H+1)/2)*randn();
                else
                    rad = 0;
                end

                A(i+1,j+1) = complex((rad*cos(phase)),(rad * sin(phase)));
                if (i==0)
                    i0=0;
                else
                    i0=N-i;
                end
                if (j==0)
                    j0=0;
                else
                    j0=N-j;
                end
                A(i0+1,j0+1) = complex((rad*cos(phase)),(-rad * sin(phase)));

            end
        end

        A(N/2+1,1) = complex(real(A(N/2+1,1)),0);
        A(1, N/2+1) = complex(real(A(1, N/2+1)),0);
        A(N/2+1,N/2+1) = complex(real(A(N/2+1,N/2+1)),0);

        for i=1:N/2-1
            for j=1:N/2-1
                phase = 2*pi*rand();
                rad = power(i*i+j*j,-(H+1)/2)*randn();
                A(i+1,N-j+1) = complex((rad*cos(phase)),(rad * sin(phase)));
                A(N-i+1,j+1) = complex((rad*cos(phase)),(rad * sin(phase)));
            end
        end
        % --- end of Saupe algorithm ---
        
        % inverse Fourier transform to yield image
        X = ifft2(A);
        XR = real(X);
        
        % re-scale so image uses full 8-bit greyscale
        omin = min(XR(:));
        omax = max(XR(:));

        XI = uint8(round(((XR-omin)./(omax-omin)).*255));

        % show image if required
        if showim == 1
            surf( double(XI), 'LineStyle','none');

            colormap(gray(256)); % assuming 8 bit grayscale image
            view (-217, 45);
            set(gcf, 'color', 'white'); % Set the figure background to transparent 
            set(gca, 'color', 'white'); % Set the axes background to transparent
            box on;
            grid on;
        end
        
        % save image to file
        imwrite(XI, fname,'png');
        fprintf('%s: D=%g, equivalent amp slope=%g\n', fname , D, nomAmpSlope);
    end
end

